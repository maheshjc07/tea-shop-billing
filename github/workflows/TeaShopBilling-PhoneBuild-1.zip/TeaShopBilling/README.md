# TeaShop Billing (Android starter)

Native Android app starter using Kotlin + Jetpack Compose. Includes quick item selection, cart totals, complete bill, on-device sales counters, and simple stock replenishment. Currency is INR; example catalog/prices are editable in `app/src/main/java/com/example/teashopbilling/MainActivity.kt`.

## Build APK using only a phone (GitHub Actions)
1. Extract this ZIP on your phone.
2. Create a new GitHub repository in your browser.
3. Upload the contents of this folder to the repository (including `.github/workflows/build-apk.yml`).
4. Open the repository's **Actions** tab and select **Build TeaShop Billing APK**.
5. Tap **Run workflow** (or wait for the automatic build after uploading to `main`).
6. Open the completed workflow run. Download the artifact named `TeaShopBilling-debug-apk`.
7. Extract the artifact ZIP to get `app-debug.apk`, then tap it to install. Android may ask permission to install unknown apps for the browser/files app.

## Build locally
Open this folder in Android Studio, allow Gradle sync, and choose **Build > Build APK(s)**. The APK is at `app/build/outputs/apk/debug/app-debug.apk`.

## Prototype limitations
This is an early prototype, not production-ready: no GST invoice certification, printer integration, ingredient recipes, customer dues, cloud sync, backup, or date-wise reporting yet. Verify GST and accounting requirements before commercial use.
