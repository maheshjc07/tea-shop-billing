package com.example.teashopbilling

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject

private data class Product(val id: Int, val name: String, val price: Double, val stock: Int)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TeaShopApp(getPreferences(MODE_PRIVATE)) }
    }
}

@Composable
private fun TeaShopApp(prefs: android.content.SharedPreferences) {
    val initial = listOf(
        Product(1, "Tea", 12.0, 100), Product(2, "Coffee", 18.0, 80),
        Product(3, "Ginger Tea", 15.0, 60), Product(4, "Samosa", 15.0, 50),
        Product(5, "Biscuit", 5.0, 120), Product(6, "Water Bottle", 20.0, 40)
    )
    var products by remember { mutableStateOf(loadProducts(prefs, initial)) }
    var cart by remember { mutableStateOf(mapOf<Int, Int>()) }
    var sales by remember { mutableStateOf(prefs.getFloat("sales", 0f).toDouble()) }
    var billCount by remember { mutableStateOf(prefs.getInt("bills", 0)) }
    var tab by remember { mutableStateOf("Billing") }
    var message by remember { mutableStateOf("") }
    val total = cart.entries.sumOf { (id, qty) -> (products.firstOrNull { it.id == id }?.price ?: 0.0) * qty }
    val bg = Color(0xFFF5F7F5)
    MaterialTheme(colorScheme = lightColorScheme(primary = Color(0xFF176B4D), background = bg)) {
        Scaffold(containerColor = bg, bottomBar = {
            NavigationBar {
                listOf("Billing", "Stock", "Reports").forEach { item ->
                    NavigationBarItem(selected = tab == item, onClick = { tab = item }, icon = { Text(when(item){"Billing"->"🧾";"Stock"->"📦";else->"📊"}) }, label = { Text(item) })
                }
            }
        }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
                Text("TeaShop Billing", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Color(0xFF164B38))
                Text("Counter billing • works offline", color = Color.Gray, fontSize = 13.sp)
                Spacer(Modifier.height(14.dp))
                when(tab) {
                    "Billing" -> {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            SummaryCard("Today's sales", "₹${"%.2f".format(sales)}", Modifier.weight(1f))
                            SummaryCard("Bills", "$billCount", Modifier.weight(1f))
                        }
                        Spacer(Modifier.height(12.dp))
                        Text("Tap an item to add to bill", fontWeight = FontWeight.SemiBold)
                        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(products) { p ->
                                Row(Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(14.dp)).clickable {
                                    if ((cart[p.id] ?: 0) < p.stock) cart = cart + (p.id to ((cart[p.id] ?: 0) + 1)) else message = "Stock limit reached"
                                }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) { Text(p.name, fontWeight = FontWeight.Bold); Text("₹${p.price} • Stock ${p.stock}", color = Color.Gray, fontSize = 12.sp) }
                                    Text("＋", color = Color(0xFF176B4D), fontSize = 25.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                        if (cart.isNotEmpty()) {
                            Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                                Column(Modifier.padding(12.dp)) {
                                    Text("Current bill", fontWeight = FontWeight.Bold)
                                    cart.forEach { (id, qty) -> Text("${products.first { it.id == id }.name}  × $qty  — ₹${products.first { it.id == id }.price * qty}") }
                                    Divider(Modifier.padding(vertical = 6.dp))
                                    Text("Total  ₹${"%.2f".format(total)}", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        OutlinedButton(onClick = { cart = emptyMap(); message = "Bill cleared" }, modifier = Modifier.weight(1f)) { Text("Clear") }
                                        Button(onClick = {
                                            products = products.map { p -> p.copy(stock = (p.stock - (cart[p.id] ?: 0)).coerceAtLeast(0)) }
                                            sales += total; billCount++
                                            prefs.edit().putFloat("sales", sales.toFloat()).putInt("bills", billCount).putString("products", encode(products)).apply()
                                            cart = emptyMap(); message = "Bill saved • ₹${"%.2f".format(total)}"
                                        }, modifier = Modifier.weight(1f)) { Text("Complete bill") }
                                    }
                                }
                            }
                        }
                    }
                    "Stock" -> {
                        Text("Inventory", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        LazyColumn(Modifier.weight(1f)) { items(products) { p ->
                            Row(Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(12.dp)).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) { Text(p.name, fontWeight = FontWeight.Bold); Text("₹${p.price} • ${p.stock} units", color = Color.Gray) }
                                TextButton(onClick = { products = products.map { if(it.id==p.id) it.copy(stock=it.stock+10) else it }; prefs.edit().putString("products", encode(products)).apply() }) { Text("+10") }
                            }; Spacer(Modifier.height(7.dp))
                        } }
                    }
                    else -> {
                        Text("Sales overview", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        SummaryCard("Sales recorded on this device", "₹${"%.2f".format(sales)}", Modifier.fillMaxWidth())
                        Spacer(Modifier.height(8.dp)); SummaryCard("Bills completed", "$billCount", Modifier.fillMaxWidth())
                        Text("This starter version tracks totals locally. Date-wise reporting and export can be added next.", color = Color.Gray, fontSize = 13.sp)
                    }
                }
                if(message.isNotBlank()) { Spacer(Modifier.height(5.dp)); Text(message, color = Color(0xFF176B4D)); message = "" }
            }
        }
    }
}

@Composable private fun SummaryCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.padding(14.dp)) { Text(label, fontSize = 12.sp, color = Color.Gray); Text(value, fontSize = 21.sp, fontWeight = FontWeight.Bold, color = Color(0xFF176B4D)) }
    }
}

private fun encode(products: List<Product>): String = JSONArray().apply { products.forEach { p -> put(JSONObject().put("id",p.id).put("name",p.name).put("price",p.price).put("stock",p.stock)) } }.toString()
private fun loadProducts(prefs: android.content.SharedPreferences, defaults: List<Product>): List<Product> {
    val raw = prefs.getString("products", null) ?: return defaults
    return try { val a=JSONArray(raw); (0 until a.length()).map { val o=a.getJSONObject(it); Product(o.getInt("id"),o.getString("name"),o.getDouble("price"),o.getInt("stock")) } } catch (_: Exception) { defaults }
}
